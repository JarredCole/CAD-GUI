import json
import sys
import os
import re
from collections import defaultdict


class NSD:
    def __init__(self):
        self.nsd = {
            "nsdInvariantId": "Network designs",
            "nsdIdentifier": "",
            "designer": "Ciena Corp",
            "version": "0.0.1",
            "virtualLinkDesc": [],
            "sapd": [],
            "vnffgd": [],
            "vnfdId": [],
            "nsDf": [],
            "cpdPool": []
            }
        self.cpd_pool = "datapath_cpdpool"
        self.all_vnfds = defaultdict(dict)
        # Example of self.all_vnfds
        # {'vyos_1_03': {'vyos_mgmt_dps5': {'vld': 'mgmt', 'sapd': 'mgmt_lp4', 'inter_vld': ''},
        #                'vyos_lan_dp0s6': {'vld': 'lan', 'sapd': 'lan_lp2',
        #                           'inter_vld': 'interconnect_nios_lan_1_vyos_lan_dp0s6'},
        #                'vyos_lan2_ha_dp0s7': {'vld': 'ha', 'sapd': 'ha_lp3', 'inter_vld': ''},
        #                'vyos_wan_fp': {'vld': 'wan', 'sapd': 'wan_lp1', 'inter_vld': ''}},
        # 'nios_8_3_2': {'nios_mgmt': {'vld': 'lan_1', 'sapd': 'lan_1_lp6', 'inter_vld': ''},
        #               'nios_lan_1': {'vld': 'lan', 'sapd': 'lan_lp2',
        #               'inter_vld': 'interconnect_nios_lan_1_vyos_lan_dp0s6'}}})

    def get_metadata_sapd(self, vlan, saos_port):
        # TODO : Add more metadata types
        if vlan == "127":
            return {}
        built_in = saos_port
        metadata = {
            "keyValuePairs": [
              {
                "key": "keyvalue.resourceTypes.ZSapdKeyVirtualNetworkPortBuiltin",
                "value": {
                  "virtualNetworkPort": {
                    "built-in": built_in
                  }
                }
              },
              {
                "key": "keyvalue.resourceTypes.ZSapdKeyVirtualNetworkPortClassifiers",
                "value": {
                  "virtualNetworkPort": {
                    "classifiers": [
                      {
                        "filterOperation": "match-all",
                        "name": "VLAN-" + str(vlan),
                        "filters": [
                          {
                            "type": "tagged",
                            "vtags": [
                              {
                                "tpid": "8100",
                                "vlan": int(vlan)
                              }
                            ]
                          }
                        ]
                      }
                    ]
                  }
                }
              },
              {
                "key": "keyvalue.resourceTypes.ZSapdKeyVirtualNetworkPortTransforms",
                "value": {
                  "virtualNetworkPort": {
                    "transforms": [
                      {
                        "name": "pop",
                        "type": "ingress",
                        "transformOption": [
                          {
                            "frameType": "single-tagged",
                            "tag": "outer",
                            "operation": "pop"
                          }
                        ]
                      },
                      {
                        "name": "push-" + str(vlan),
                        "type": "egress",
                        "transformOption": [
                          {
                            "frameType": "single-tagged",
                            "tag": "outer",
                            "tpid": "tpid-8100",
                            "operation": "push",
                            "vlan": int(vlan)
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            ]
          }
        return { "metadata" : metadata }

    def get_metadata_vld(self, vlan):
        metadata = {}
        # TODO : Add more metadata types
        if vlan == "127":
            metadata = {
                "keyValuePairs" : [
                    {
                        "key": "keyvalue.resourceTypes.ZVlDescKeyVirtualNetworkBuiltin",
                        "value": {
                            "virtualNetwork": {
                                "built-in": "mgmtbr0"
                            }
                        }
                    }
                ]
            }
        return metadata

    def get_metadata_nsdf(self):
        # TODO : Add more metadata types
        metadata = {
            "keyValuePairs": [
                {
                    "key": "keyvalue.resourceTypes.ZNsVlConnCpdKeyVirtualNetworkPortClassifiers",
                    "value": {
                        "virtualNetworkPort": {
                            "classifiers": [
                                {
                                    "filterOperation": "match-all",
                                    "name": "UNTAGGED",
                                    "filters": [
                                        {
                                            "type": "untagged"
                                        }
                                    ]
                                },
                                {
                                    "filterOperation": "match-all",
                                    "name": "ANY",
                                    "filters": [
                                        {
                                            "type": "tagged"
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            ]
        }
        return metadata

    def create_sapd(self, vld, saos_port, metadata):
        alr_present = False
        sapd = vld + "_lp" + str(saos_port)
        for sapds in self.nsd["sapd"]:
            if sapds["sapd"]["cpd"]["cpdId"] == sapd:
                alr_present = True
        if not alr_present:
            cpd =  {
                "layerProtocol": [
                    "IPv4"
                ],
                "cpdId": sapd,
            }

            if metadata:
                cpd.update(metadata)

            sapd_dict = {
                "sapd": {
                    "cpd": cpd,
                    "nsVirtualLinkDescId": vld,
                    "sapAddressAssignment": False
                },
                "associatedWith": "VLD"
            }
            self.nsd["sapd"].append(sapd_dict)
        return sapd

    def create_vld(self, vld, vlan, interfaces):
        alr_present = False
        name = ""
        if len(interfaces) == 2 and (vlan != "127" or not vlan):
            name = "interconnect_" + interfaces[0] + "_" + interfaces[1]
        for vlds in self.nsd["virtualLinkDesc"]:
            if vlds["virtualLinkDesc"]["virtualLinkDescId"] == vld \
                    or vlds["virtualLinkDesc"]["virtualLinkDescId"] == name:
                alr_present = True
        if not alr_present:
            if len(interfaces) == 2 and (vlan != "127" or not vlan):
                # create VLD entry for interconnect
                conf1 = {
                    "virtuaLinkDescVersion": "1.0.0",
                    "virtualLinkDesc": {
                        "connectivityType": {
                            "layerProtocol": "IPV4"
                        },
                        "virtualLinkDescId": name
                    }
                }
                #if vlan:
                #    conf2 = self.get_metadata_vld(vlan)
                #    if conf2:
                #       conf2 = {"metadata" : conf2}
                #    self.nsd["virtualLinkDesc"].append({**conf1, **conf2})
                #else:
                self.nsd["virtualLinkDesc"].append(conf1)
            if vld:
                conf1 = {
                    "virtuaLinkDescVersion": "1.0.0",
                    "virtualLinkDesc": {
                        "connectivityType": {
                            "layerProtocol": "IPV4"
                        },
                        "virtualLinkDescId": vld
                    }
                }
                conf2 = self.get_metadata_vld(vlan)
                if conf2:
                    conf2 = {"metadata" : conf2}
                self.nsd["virtualLinkDesc"].append({**conf1, **conf2})
        return name

    def create_datapath(self, all_links, vnfds, all_interfaces, interconnects):
        paths = []
        next_vnf_interface = ""
        links = all_links[:]
        vlds = ["lan", "wan", "mgmt", "ha"]

        if links:
            for link in all_links:
                vld = ((re.search("(.*)\s?=\s?\[", link)).group(1)).lower()
                vld = "".join(vld.split())
                interfaces = ((re.search("\[(.*)\]", link)).group(1)).split(",")
                interfaces = ["".join(i.split()) for i in interfaces]

                if vld in vlds:
                    links.remove(link)
                    continue
                if "mgmt" in [i.lower() for i in interfaces]:
                    links.remove(link)
                    continue

                if len(interfaces) == 2:
                    local_interfaces = interfaces[:]
                    for intf in interfaces:
                        if intf in all_interfaces:
                            local_interfaces.remove(intf)
                            next_vnf_interface = local_interfaces[0]
                            paths.append({vld : interfaces})
                            links.remove(link)
            if paths:
                interconnects.append(paths)

            interfaces_list = []
            vnf = ""
            for vnfd in vnfds:
                for intf in self.all_vnfds[vnfd]:
                    if intf == next_vnf_interface:
                        vnf = vnfd
            for intf in self.all_vnfds[vnf]:
                interfaces_list.append(intf)

            if interfaces_list:
                interconnects = self.create_datapath(links, vnfds, interfaces_list, interconnects)
        return interconnects

    def create_vnffgd(self, data):
        lan_data = defaultdict(list)
        wan_data = defaultdict(list)
        vnfds = ["".join(vnfd_id.split()) for vnfd_id in data["VNFD_ID"].split("\n")]
        all_lan_interfaces = []
        all_vnf_interfaces = {}
        lan_vnfs = []
        for vnfd in vnfds:
            for intf, info in self.all_vnfds[vnfd].items():
                all_vnf_interfaces.update({intf : vnfd})
                if info and info["vld"] == "lan":
                    lan_data["interfaces"].append([intf, vnfd])
                    lan_data["sapd"] = info["sapd"]
                    lan_vnfs.append(vnfd)
                if info and info["vld"] == "wan":
                    wan_data["interfaces"].append([intf, vnfd])
                    wan_data["sapd"] = info["sapd"]
        for vnf in lan_vnfs:
            for intf, info in self.all_vnfds[vnf].items():
                all_lan_interfaces.append(intf)

        interconnects = list()
        all_links = "".join(data["LINKS"])
        all_links = all_links.split("\n")
        interconnects = self.create_datapath(all_links, vnfds, all_lan_interfaces, interconnects)

        flavour = data["DEPLOYMENT_FLAVOUR"]
        datapath = []
        if interconnects:
            for element in interconnects[0]:
                datapath.append([element])

            for element_list in interconnects[1:]:
                new_datapath = []
                for element in element_list:
                    for interconnect in datapath:
                        x = interconnect[:]
                        x.append(element)
                        new_datapath.append(x)
                datapath = new_datapath[:]

        if datapath:
            index = 0
            for path_list in datapath:
                index = index + 1
                cpd = []
                vld_ids = []
                if lan_data:
                # lan entry
                    cpd.append({
                        "cpdType": "SAPD",
                        "cpdId": lan_data["sapd"]
                    })
                    for intf in lan_data["interfaces"]:
                        cpd.append({
                            "cpdType": "VNFD",
                            "cpdId": intf[0],
                            "vnfdId": intf[1]
                        })
                    vld_ids.append("lan")

                # interconnect entries
                for interconnect in path_list:
                    interfaces = interconnect[list(interconnect.keys())[0]]
                    cpd.append({
                        "cpdType": "VNFD",
                        "cpdId": interfaces[0],
                        "vnfdId": all_vnf_interfaces[interfaces[0]]
                    })
                    cpd.append({
                        "cpdType": "VNFD",
                        "cpdId": interfaces[1],
                        "vnfdId": all_vnf_interfaces[interfaces[1]]
                    })
                    vld_ids.append("interconnect_" + interfaces[0] + "_" + interfaces[1])

                # wan entry
                if wan_data:
                    for intf in wan_data["interfaces"]:
                        cpd.append({
                            "cpdType": "VNFD",
                            "cpdId": intf[0],
                            "vnfdId": intf[1]
                        })
                    cpd.append({
                        "cpdType": "SAPD",
                        "cpdId": wan_data["sapd"]
                    })
                    vld_ids.append("wan")

                nfpd = {
                    "nfpd": [
                        {
                            "nfpdId": "nfpd_" + flavour + "_" + str(index),
                            "relaxVldTraversalChecks": False,
                            "nfpRule": {
                                "name": "nfpd_" + flavour + "_" + str(index)
                            },
                            "cpd": cpd
                        }
                    ],
                    "vnffgdId": "datapath_" + flavour + "_" + str(index),
                    "cpdPoolId": [self.cpd_pool],
                    "virtualLinkDescId": vld_ids,
                    "vnfdId": vnfds
                }
                self.nsd["vnffgd"].append(nfpd)
        else:
            cpd = []
            vld_ids = []
            if lan_data:
                # lan entry
                cpd.append({
                    "cpdType": "SAPD",
                    "cpdId": lan_data["sapd"]
                })
                for intf in lan_data["interfaces"]:
                    cpd.append({
                        "cpdType": "VNFD",
                        "cpdId": intf[0],
                        "vnfdId": intf[1]
                    })
                vld_ids.append("lan")

            # wan entry
            if wan_data:
                for intf in wan_data["interfaces"]:
                    cpd.append({
                        "cpdType": "VNFD",
                        "cpdId": intf[0],
                        "vnfdId": intf[1]
                    })
                cpd.append({
                    "cpdType": "SAPD",
                    "cpdId": wan_data["sapd"]
                })
                vld_ids.append("wan")

            if cpd:
                nfpd = {
                    "nfpd": [
                        {
                            "nfpdId": "nfpd_" + flavour,
                            "relaxVldTraversalChecks": False,
                            "nfpRule": {
                                "name": "nfpd_" + flavour
                            },
                            "cpd": cpd
                        }
                    ],
                    "vnffgdId": "datapath_" + flavour,
                    "cpdPoolId": [self.cpd_pool],
                    "virtualLinkDescId": vld_ids,
                    "vnfdId": vnfds
                }
                self.nsd["vnffgd"].append(nfpd)

    def add_sapds(self, info, cpd_list):
        sapd_found = False
        for cpd in cpd_list:
            if info["sapd"] == cpd["cpdId"]:
                sapd_found = True
        return sapd_found

    def create_cpdpool(self):
        cpd = []
        for vnfd, intf_dict in self.all_vnfds.items():
            for intf, info in intf_dict.items():
                cpd.append({
                    "cpdType": "VNFD",
                    "cpdId": intf,
                    "vnfdId": vnfd
                })
                if info and info["sapd"]:
                    sapd_found = self.add_sapds(info, cpd)
                    if not sapd_found:
                        cpd.append({
                            "cpdType": "SAPD",
                            "cpdId": info["sapd"]
                        })
        self.nsd["cpdPool"].append({
            "cpdPoolId": self.cpd_pool,
            "cpdId": cpd
        })

    def get_vnf_profiles(self, data):
        profile_data = []
        profiles = []
        vlink_profiles = {}
        vnfd_ids = ["".join(vnfd_id.split()) for vnfd_id in data["VNFD_ID"].split("\n")]

        for vnfd in vnfd_ids:
            path = "tmp"
            with open(os.path.join(path, vnfd + "_VNFD.json")) as f:
                content = json.load(f)
            vl_connectivity = []
            for intf, info in self.all_vnfds[vnfd].items():
                if info:
                    metadata = self.get_metadata_nsdf()
                    if info["vld"]:
                        vl_connectivity.append({
                            "virtualLinkProfileId": info["vld"] + "_pfile_v1",
                            "cpds": [
                                {
                                    "cpdType": "VNFD",
                                    "cpdId": intf,
                                    "metadata": metadata
                                }
                            ]
                        })

                        vlink_profiles[info["vld"] + "_pfile_v1"] = info["vld"]
                    else:
                        vl_connectivity.append({
                            "virtualLinkProfileId": info["inter_vld"] + "_pfile_v1",
                            "cpds": [
                                {
                                    "cpdType": "VNFD",
                                    "cpdId": intf,
                                    "metadata": metadata
                                }
                            ]
                        })

                        vlink_profiles[info["inter_vld"] + "_pfile_v1"] = info["inter_vld"]

            profile = {
                "instantiationLevel": content["deploymentFlavors"][0]["defaultInstantiationLevel"],
                "minNumberOfInstances": 1,
                "flavourId": content["deploymentFlavors"][0]["flavourId"],
                "maxNumberOfInstances": 1,
                "vnfdId": vnfd,
                "nsOrVnfProfile": {},
                "vnfProfileId": data["DEPLOYMENT_FLAVOUR"] + "_" + vnfd + "_vnf_pfile",
                "nsVirtualLinkConnectivity": vl_connectivity

            }
            profiles.append(
                {
                    "numberOfInstances": 1,
                    "vnfProfileId": data["DEPLOYMENT_FLAVOUR"] + "_" + vnfd + "_vnf_pfile"
                }
            )
            profile_data.append(profile)

        return profile_data, profiles, vlink_profiles

    def create_nsdf(self, data):
        vlp_vld = []
        vlp_list = []

        vnf_profile_data, vnf_profiles, virtual_link_profiles  = self.get_vnf_profiles(data)
        for vlp, vld in virtual_link_profiles.items():
            vlp_vld.append({
                "maxBitrateRequirements": {
                    "root": 1000
                },
                "virtualLinkProfileId": vlp,
                "virtualLinkDescId": vld
            })
            vlp_list.append(
                {
                    "virtualLinkProfileId": vlp
                }
            )

        profiles = {
            "nsDfId": data["DEPLOYMENT_FLAVOUR"],
            "vnfProfile": vnf_profile_data,
            "flavourKey": "dummy value",
            "defaultNsInstantiationLevelId": data["DEPLOYMENT_FLAVOUR"] + "_ns_level",
            "nsInstantiationLevel": [
                {
                    "nsLevelId": data["DEPLOYMENT_FLAVOUR"] + "_ns_level",
                    "virtualLinkToLevelMapping": vlp_list,
                    "vnfToLevelMapping": vnf_profiles,
                    "description": "level description"
                }
            ],
            "virtualLinkProfile": vlp_vld
        }
        self.nsd["nsDf"].append(profiles)

    def create_nsd(self, content, vnfds_created):
        file_name = ""
        for vnfd in vnfds_created:
            file_name = file_name + vnfd.split("_")[0] + "_"
            self.nsd["vnfdId"].append(vnfd.split("_VNFD.json")[0])

        for data in content:
            vnf_content = ""
            if data["S.NO"]:
                # get all interfaces from vnfds
                vnfds = ["".join(vnfd_id.split()) for vnfd_id in data["VNFD_ID"].split("\n")]
                for vnfd in vnfds:
                    path = "tmp"
                    with open(os.path.join(path, vnfd + "_VNFD.json")) as f:
                        vnf_content = json.load(f)
                    for i in vnf_content["vnfExtCpds"]:
                        self.all_vnfds[vnf_content["vnfdId"]].update({i["cpd"]["cpdId"]: {}})

                # Process all links of a flavour
                all_links = data["LINKS"].split("\n")
                for link in all_links:
                    vlan = ""
                    saos_port = ""
                    link = "".join(link.split())
                    try:
                        vlan = re.findall("\]?,\s?(\d+)", link)[0]
                        saos_port = re.findall("\]?,\s?(\d+)", link)[1]
                    except:
                        pass
                    vld = ((re.search("(.*)\s?=\s?\[", link)).group(1)).lower()
                    interfaces = ((re.search("\[(.*)\]", link)).group(1)).split(",")
                    if not vlan and not saos_port:
                        # interconnect without sapd
                        vld = ""

                    # create VLD entry
                    inter_vld = self.create_vld(vld, vlan, interfaces)

                    sapd = ""
                    if saos_port:
                        # create sapd entry
                        metadata = self.get_metadata_sapd(vlan, saos_port)
                        sapd = self.create_sapd(vld, saos_port, metadata)

                    # update class dict
                    vnfds = ["".join(vnfd_id.split()) for vnfd_id in data["VNFD_ID"].split("\n")]
                    for vnfd in vnfds:
                        for intf in self.all_vnfds[vnfd]:
                            if intf in interfaces:
                                self.all_vnfds[vnfd][intf].update(
                                    {
                                        "vld": vld,
                                        "sapd": sapd,
                                        "inter_vld": inter_vld
                                    }
                                )
                print("All vnf data:")
                print(self.all_vnfds)

                # create flavour entry
                self.create_nsdf(data)

                # create vnffgd entry
                self.create_vnffgd(data)

            else:
                print("Json file created from xlsx is not correct!")
                sys.exit(1)

        # create cpd pool entry only once
        self.create_cpdpool()

        # set NSD id
        self.nsd["nsdIdentifier"] = file_name + "NSD"

        path = "tmp"
        filename = file_name + "NSD.json"

        with open(os.path.join(path, filename), 'w') as outfile:
            json.dump(self.nsd, outfile, indent=4, sort_keys=True)

        return filename


if __name__ == "__main__":
    pass
