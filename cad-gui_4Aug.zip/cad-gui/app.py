from flask import Flask, render_template, request, json, jsonify, send_file, session, url_for, redirect
from create_vnfd import create_vnfds
from create_nsd import NSD
from zipfile import ZipFile
import os
from os.path import basename

app = Flask(__name__)


class User:
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password

    def __repr__(self):
        return f'<User: {self.username}>'


users = []

users.append(User(id=1, username='Ciena', password='ciena123'))

app.secret_key = 'somesecretkeyonlyiknow'


@app.route('/' , methods =['GET', 'POST'])
def login():
    if request.method == 'POST':
        session.pop('user_id', None)
        username = request.form['username']
        password = request.form['password']

        user = [x for x in users if x.username == username][0]
        if user and user.password == password:
            session['user_id'] = user.id
            return redirect(url_for('index'))
        if user and user.password != password:
            session['user_id'] = user.id
            return redirect(url_for('login'))

    return render_template('login.html')


@app.route('/index')
def index():
    return render_template('index.html')


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/nsd')
def nsd():
    return render_template('nsd.html')


@app.route('/downloads')
def downloads():
    return render_template('downloads.html')


@app.route('/download')
def download_file():
    path = "tmp"
    entries = os.listdir(path)
    files = [filename + filext for filename, filext in [os.path.splitext(entry)
                                                        for entry in entries] if filext == ".json"]
    print("Json files available are:")
    print(files)

    zip_file = "/" + path + "/" + "all_json_files.zip"

    # create a ZipFile object
    with ZipFile(zip_file, 'w') as zipObj:
        # Iterate over all the files in directory
        for folderName, subfolders, filenames in os.walk(path):
            for filename in filenames:
                if filename in files:
                    # create complete filepath of file in directory
                    filePath = os.path.join(folderName, filename)
                    # Add file to zip
                    zipObj.write(filePath, basename(filePath))

    return send_file(zip_file, as_attachment=True)


@app.route('/result', methods=['POST', 'GET'])
def process_result():
    path = "tmp"
    entries = os.listdir(path)
    files = [filename + filext for filename, filext in [os.path.splitext(entry)
                                                        for entry in entries] if filext == ".json"]
    for f in files:
        os.remove(os.path.join(path, f))

    userInfo = request.json["vnfds"]
    data = []
    counter = 1
    for info in userInfo:
        flavour = []
        final_flv = ""
        interfaces = "\n".join(info["interfaces"])
        for flv in info["flavour"]:
            cpu = flv["vCPUs"]
            memory = flv["memory"]
            flavour.append("vCPUs=" + cpu + ", memory=" + memory + "\n")

        for flv in flavour:
            final_flv = final_flv + flv

        data.append({
            'S.NO': counter,
            'VENDOR': info["vendor"],
            'VNFD_ID': info["vnfd_id"],
            'IMAGE_NAME': info["image_name"],
            'VNC_PASSWORD': info["vnc_password"],
            'DAY0_ISO': info["day0_iso"],
            'INTERFACES': interfaces,
            'FLAVOUR': final_flv[:-1]
        })
        counter = counter + 1

    print("### VNFD DATA ###")
    print(data)
    print("################")
    create_vnfds(data)

    entries = os.listdir(path)
    files = [filename + filext for filename, filext in [os.path.splitext(entry)
                                                        for entry in entries] if filext == ".json"]
    print("VNFD files are:")
    print(files)

    userInfo = request.json["nsd"]
    data = []
    counter = 1
    for i in userInfo:
        vnfds = "\n".join(i["vnfd_id"])
        final_link = ""
        links = []
        for k in i["links"]:
            intf = ", ".join(k["interfaces"])
            if k["vlan"] and k["lp"] and k["lp"] != "Choose logical port":
                link = k["name"] + "=[" + intf + "], " + k["vlan"] + ", " + k["lp"] + "\n"
            else:
                link = k["name"] + "=[" + intf + "]" + "\n"
            links.append(link)

        for link in links:
            final_link = final_link + link

        data.append({
            'S.NO': counter,
            'DEPLOYMENT_FLAVOUR': i["dp_name"],
            'VNFD_ID': vnfds,
            'LINKS': final_link[:-1]
        })
        counter = counter + 1

    print("### NSD DATA ###")
    print(data)
    print("################")
    n = NSD()
    file_name = n.create_nsd(data, vnfds_created=files)
    print(file_name)

    return render_template("index.html", data=userInfo)


if __name__ == '__main__':
    app.run(debug=True)
