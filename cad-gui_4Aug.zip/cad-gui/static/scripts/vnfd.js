let interfaces = [];
let flavours = [];
let links = []

const addVnfd = (ev) => {
    ev.preventDefault(); //stops form from submitting
    let intf = interfaces.slice();
    let flv = flavours.slice();
    if (localStorage.getItem("vnfds") === null) {
        window.localStorage.setItem("vnfds", JSON.stringify([]));
    }
    let vnfds = JSON.parse(window.localStorage.getItem('vnfds'));

    const vnfd = {
        vendor: document.getElementById('vendor').value,
        vnfd_id: document.getElementById('vnfd_id').value,
        image_name: document.getElementById('image_name').value,
        interfaces: intf,
        flavour: flv,
        day0_iso: document.getElementById('day0_iso').value,
        vnc_password: document.getElementById('vnc_password').value
    }
    vnfds.push(vnfd);
    window.localStorage.setItem("vnfds", JSON.stringify(vnfds));
    document.forms[0].reset(); //clears form for next entry

    interfaces.splice(0, interfaces.length);
    flavours.splice(0, flavours.length);

    // displays array
    console.warn('added' , {vnfds} );
    let pre = document.querySelector('#msg pre'); // connects to the id msg on index.html to show preview of data.
    pre.textContent = '\n' + JSON.stringify(vnfds, '\t', 2);
}

document.addEventListener('DOMContentLoaded', ()=>{
    document.getElementById('addvnfd').addEventListener('click', addVnfd);
});

const deleteVnfd = (ev) => {
    ev.preventDefault();
    let vnfd_id = document.getElementById('vnfd_id').value
    if (localStorage.getItem("vnfds") === null) {
        window.localStorage.setItem("vnfds", JSON.stringify([]));
    }
    let vnfds = JSON.parse(window.localStorage.getItem('vnfds'));
    for (let vnfd = 0; vnfd < vnfds.length; vnfd++) {
        if (vnfds[vnfd]['vnfd_id'] === vnfd_id) {
            vnfds.splice(vnfd, 1)
        }
    }
    window.localStorage.setItem("vnfds", JSON.stringify(vnfds));
    document.forms[0].reset();

    interfaces.splice(0, interfaces.length)
    flavours.splice(0, flavours.length)

    // displays array
    console.warn('deleted' , {vnfds})
    let pre = document.querySelector('#msg pre'); // connects to the id msg on index.html to show preview of data.
    pre.textContent = '\n' + JSON.stringify(vnfds, '\t', 2);
}

document.addEventListener('DOMContentLoaded', ()=>{
    document.getElementById('deleteVnfd').addEventListener('click', deleteVnfd);
});

const addNsdFlavour = (ev) => {
    ev.preventDefault(); //stops form from submitting
    let link_list = links.slice();
    let dp = document.getElementById('dp').value;
    let vnfd_ids = [];
    for (let option of document.getElementById('vnfdId').options)
    {
        if (option.selected) {
            vnfd_ids.push(option.value);
        }
    }
    if (localStorage.getItem("nsd") === null) {
        window.localStorage.setItem("nsd", JSON.stringify([]));
    }
    let nsd = JSON.parse(window.localStorage.getItem('nsd'));
    const flavour = {
        links: link_list,
        vnfd_id: vnfd_ids,
        dp_name: dp
    }

    nsd.push(flavour);

    window.localStorage.setItem("nsd", JSON.stringify(nsd));
    document.forms[0].reset();

    links.splice(0, links.length)

    // displays array
    console.warn('added' , {nsd} );
    let pre = document.querySelector('#msg pre'); // connects to the id msg on index.html to show preview of data.
    pre.textContent = '\n' + JSON.stringify(nsd, '\t', 2);
}

document.addEventListener('DOMContentLoaded', ()=>{
    document.getElementById('addNsdFlavour').addEventListener('click', addNsdFlavour);
});

const deleteNsdFlavour = (ev) => {
    ev.preventDefault(); //stops form from submitting
    let dp = document.getElementById('dp').value
    if (localStorage.getItem("nsd") === null) {
        window.localStorage.setItem("nsd", JSON.stringify([]));
    }
    let nsd = JSON.parse(window.localStorage.getItem('nsd'));
    for (let i = 0; i < nsd.length; i++) {
        if (nsd[i]['dp_name'] === dp) {
            nsd.splice(i, 1)
        }
    }
    window.localStorage.setItem("nsd", JSON.stringify(nsd));
    document.forms[0].reset();

    links.splice(0, links.length)

    // displays array
    console.warn('deleted' , {nsd} );
    let pre = document.querySelector('#msg pre'); // connects to the id msg on index.html to show preview of data.
    pre.textContent = '\n' + JSON.stringify(nsd, '\t', 2);
}

document.addEventListener('DOMContentLoaded', ()=>{
    document.getElementById('deleteNsdFlavour').addEventListener('click', deleteNsdFlavour);
});

function getVnfds() {
    return JSON.parse(window.localStorage.getItem('vnfds'));
}

function getNsd() {
    return JSON.parse(window.localStorage.getItem('nsd'));
}

function postData() {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", '/result', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify({
        "vnfds": getVnfds(),
        "nsd": getNsd()
    }));
}

function addInterfaces() {
    let interfaceName = document.getElementById('interfaces').value
    interfaces.push(interfaceName)
    document.forms[0].reset();
}

function deleteInterfaces() {
    let interfaceName = document.getElementById('interfaces').value
    let i;
    for (i = 0; i < interfaces.length; i++) {
        if (interfaces[i] === interfaceName) {
            interfaces.splice(i, 1)
        }
    }
    document.forms[0].reset();
}

function addFlavours() {
    let cpu = document.getElementById('cpu').value
    let memory = document.getElementById('memory').value
    let flavour = { "vCPUs" : cpu , "memory" : memory }
    flavours.push(flavour)
    document.forms[0].reset();
}

function deleteFlavours() {
    let cpu = document.getElementById('cpu').value
    let memory = document.getElementById('memory').value
    let j;
    let memory_list;
    let cpu_list;
    for (j = 0; j < flavours.length; j++) {
        memory_list = flavours[j]["memory"]
        cpu_list = flavours[j]["vCPUs"]
        if (cpu === cpu_list && memory === memory_list) {
            flavours.splice(j, 1)
        }
    }
    document.forms[0].reset();
}

function addLinks() {
    let link_name = document.getElementById('links').value
    let interfaces = [];
    for (let option of document.getElementById('intfs').options)
    {
        if (option.selected) {
            interfaces.push(option.value);
        }
    }
    let vlan = document.getElementById('vlan').value
    let lp = document.getElementById('lp').value

    let link = { "name" : link_name, "interfaces" : interfaces, "vlan" : vlan, "lp" : lp }
    links.push(link)
    document.forms[0].reset();
}

function deleteLinks() {
    let link_name = document.getElementById('links').value
    for (let j = 0; j < links.length; j++) {
        name = links[j]["name"]
        if (link_name === name) {
            links.splice(j, 1)
        }
    }
    document.forms[0].reset();
}

window.addEventListener("load", function() {
    let vnfds = JSON.parse(window.localStorage.getItem('vnfds'));
    let vnfd_ids = [];
    let interface_list = [];

    for(let i = 0; i< vnfds.length; i++) {
        vnfd_ids.push(vnfds[i]["vnfd_id"])
        for(let j = 0; j<vnfds[i]["interfaces"].length; j++)
            interface_list.push(vnfds[i]["interfaces"][j])
    }

    for(let i = 0; i < vnfd_ids.length; i++) {
        const name = vnfd_ids[i];
        const sel = document.querySelector("[name=vnfd_id]");
        sel.options[sel.options.length] = new Option(name);
    }
    for(let i = 0; i < interface_list.length; i++) {
        const name = interface_list[i];
        const sel = document.querySelector("[name=intfs]");
        sel.options[sel.options.length] = new Option(name);
    }
})