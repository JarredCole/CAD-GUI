import vnfd.js

let nsd = []
let intfs = []
function getVnfdId() {
    var select = document.getElementById("selectNumber");
    var options = sessionStorage.getItem("vnfds");
    for (var i = 0; i < options.length; i++) {
        var opt = options[i];
        var el = document.createElement("option");
        el.textContent = opt;
        el.value = opt;
        select.appendChild(el);
    }
}

function addInterfacesNsd() {
    var li = document.createElement("LI");
    var input = document.getElementById("add");
    li.innerHTML = input.value;
    input.value = "";
    document.getElementById("faves").appendChild(li);
}

function addLinks() {

}

function addNsdFlavour() {

}