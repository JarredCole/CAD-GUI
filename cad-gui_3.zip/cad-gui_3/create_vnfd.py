import json
import sys
import os

def get_conf_prop(data):
    conf1 = {}
    conf2 = {}
    if data["VNC_PASSWORD"] and data["VNC_PASSWORD"] != "NA":
        conf1 = {"contentObscured": {"vnc": {"password": data["VNC_PASSWORD"] }}}
    if data["DAY0_ISO"] and data["DAY0_ISO"] != "NA":
        content = "{\r\n   \"driverType\":\"ide\",\r\n   \"location\":\"vdc\",\r\n   \"isoFile\":\"vnf_iso\",\r\n   \"files\":[{\r\n   \"name\" : \"vnf_iso\",\r\n   \"fileType\": \"cloud-init-iso\",\r\n   \"filePath\": \"customer.iso\",\r\n   \"downloadSize\": 500,\r\n   \"maxSize\": 510\r\n   }]\r\n}"
        content = content.replace("vnf_iso", data["VENDOR"] + "_iso")
        content = content.replace("customer.iso", data["DAY0_ISO"])
        conf2 = {
            "method": "ISO",
            "content": content
        }
    conf = {**conf1, **conf2}
    return conf


def create_vnfds(content):
    for data in content:
        conf_data = get_conf_prop(data)
        defaultInstantiationLevel = ""
        VNFD = {
            "vnfSoftwareVersion": "",
            "vnfdId": "",
            "vnfdOperationalState": "ENABLED",
            "vnfdProductName": "",
            "vnfProvider": "",
            "vnfProductInfoName": "",
            "vnfProductInfoDescription": "",
            "softwareImages": [],
            "vnfdVersion": "",
            "virtualComputeDescs": [],
            "intCpds": [],
            "vnfExtCpds": [],
            "vdus": [],
            "vduProfiles": [],
            "instantiationLevels": [],
            "deploymentFlavors": []
        }
        if data["S.NO"]:
            VNFD["vnfSoftwareVersion"] = data["IMAGE_NAME"].split(".")[0]
            VNFD["vnfdId"] = data["VNFD_ID"]
            VNFD["vnfdProductName"] = data["IMAGE_NAME"].split(".")[0]
            VNFD["vnfProvider"] = data["VENDOR"]
            VNFD["vnfProductInfoName"] = data["VENDOR"]
            VNFD["vnfProductInfoDescription"] = data["VENDOR"]
            VNFD["softwareImages"].append(data["IMAGE_NAME"].split(".")[0])
            VNFD["vnfdVersion"] = "0.0.1"
            if data["DAY0_ISO"] and data["DAY0_ISO"] != "NA":
                VNFD.update({"additionalArtifacts": [data["DAY0_ISO"]]})

            # cpds
            icpds = data["INTERFACES"].split("\n")
            for icpd in icpds:
                icpd = "".join(icpd.split())
                # internal cpds
                VNFD["intCpds"].append(
                    {
                        "cpd": {
                            "layerProtocol": [
                                "IPv4"

                            ],
                            "cpdId": icpd + "_icpd"
                        }
                    }
                )
                # External cpds
                VNFD["vnfExtCpds"].append(
                    {
                        "intCpd": icpd + "_icpd",
                        "cpd": {
                            "layerProtocol": [
                                "IPv4"
                            ],
                            "cpdId": icpd
                        }
                    }
                )

            # levels
            levels = data["FLAVOUR"].split("\n")
            count = 1
            for level in levels:
                level = "".join(level.split())
                cpu = level.split(",")[0].split("=")[1]
                memory = level.split(",")[1].split("=")[1]
                # vcds
                VNFD["virtualComputeDescs"].append(
                    {
                        "virtualMemory": {
                            "virtualMemSize": int(memory)
                        },
                        "virtualComputeDescId": data["VENDOR"] + "_" + memory + "_" + cpu + "_vcd_" + str(count),
                        "virtualCpu": {
                            "numVirtualCpu": int(cpu)
                        }
                    }
                )
                # vdus
                vdu = {
                        "intCpd": [icpd["cpd"]["cpdId"] for icpd in VNFD["intCpds"]],
                        "swImageDesc": data["IMAGE_NAME"].split(".")[0],
                        "virtualComputeDesc":  data["VENDOR"] + "_" + memory + "_" + cpu + "_vcd_" + str(count),
                        "name":  data["VENDOR"] + "_" + memory + "_" + cpu + "_VDU_" + str(count),
                        "vduId":  data["VENDOR"] + "_" + memory + "_" + cpu + "_vdu_" + str(count)
                    }
                if conf_data:
                    vdu.update({
                        "configurableProperties": {
                            "additionalVnfcConfigurableProperty": {
                                "userData": conf_data
                            }
                        }
                    })
                VNFD["vdus"].append(vdu)

                # vdu Profiles
                VNFD["vduProfiles"].append(
                    {
                        "minNumberOfInstances": 1,
                        "vduProfileId":  data["VENDOR"] + "_" + memory + "_" + cpu + "_vdu_pfile_" + str(count),
                        "maxNumberOfInstances": 1,
                        "vduId":  data["VENDOR"] + "_" + memory + "_" + cpu + "_vdu_" + str(count)
                    }
                )

                # Instantiation levels
                VNFD["instantiationLevels"].append(
                    {
                        "levelId": data["VENDOR"] + memory + "_" + cpu + "_Size_" + str(count),
                        "vduLevel": [{
                            "vduLevelId": data["VENDOR"] + "_" + memory + "_" + cpu + "_vdu_level_" + str(count),
                            "vduId": data["VENDOR"] + "_" + memory + "_" + cpu + "_vdu_" + str(count),
                            "numberOfInstances": 1
                        }]
                    }
                )

                # default level
                if count == 1:
                    defaultInstantiationLevel = data["VENDOR"] + memory + "_" + cpu + "_Size_" + str(count)
                count = count + 1

            # deploymentFlavours
            VNFD["deploymentFlavors"].append(
                {
                    "vduProfile": [profile["vduProfileId"] for profile in VNFD["vduProfiles"]],
                    "defaultInstantiationLevel": defaultInstantiationLevel,
                    "vnfLcmOperationsConfiguration": {
                        "scaleVnfOpConfig": {
                            "scalingByMoreThanOneStepSupported": False
                        }
                    },
                    "flavourId": data["VENDOR"] + "_flavor",
                    "instantiationLevel": [level["levelId"] for level in VNFD["instantiationLevels"]]
                }
            )

            path = os.path.dirname(os.path.realpath('__file__'))
            if not os.path.exists(path):
                os.makedirs(path)

            filename = data["VNFD_ID"] + "_VNFD.json"

            with open(os.path.join(path, filename), 'w') as outfile:
                json.dump(VNFD, outfile, indent=4, sort_keys=True)

        else:
            print("Json file created from xlsx is not correct!")
            sys.exit(1)


if __name__ == "__main__":
    pass

